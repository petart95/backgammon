//
//  ViewController.h
//  backgamon
//
//  Created by maxeler on 1/20/17.
//  Copyright © 2017 maxeler. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property NSInteger gameLength;
@property NSInteger redBotDif;
@property NSInteger whiteBotDif;

@end


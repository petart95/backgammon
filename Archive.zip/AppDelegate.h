//
//  AppDelegate.h
//  backgamon
//
//  Created by maxeler on 1/20/17.
//  Copyright © 2017 maxeler. All rights reserved.
//

#import "MaxelerAppDelegate.h"

@interface AppDelegate : MaxelerAppDelegate


@end


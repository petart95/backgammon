//
//  RectangleView.m
//  backgamon
//
//  Created by maxeler on 1/26/17.
//  Copyright © 2017 maxeler. All rights reserved.
//

#import "RectangleView.h"
#import "MaxColor.h"

@implementation RectangleView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    
    if (self) {
        self.bottomColor = [UIColor translucentColorFromColor:[UIColor brownColor] withAlpha:0.75];
        self.backgroundColor = [UIColor clearColor];
    }
    
    return self;
}

- (void)drawRect:(CGRect)rect {/*
    CGSize size = self.frame.size;
    
    CGPoint center = CGPointMake(size.width / 2, 0);
    CGPoint bottomLeft = CGPointMake(0, size.height - 0);
    CGPoint bottomRight = CGPointMake(size.width - 0, size.height - 0);
    
    CGFloat a = size.width;
    CGFloat b = hypotf(center.x - bottomLeft.x, center.y - bottomLeft.y);
    CGFloat s = (2*b+a)/2;
    CGFloat radius = sqrt((s-a)*(s-b)*(s-b)/s);
    CGFloat scale = radius / size.height;
    CGPoint innerCircleTouchPoint = CGPointMake(bottomLeft.x + (center.x - bottomLeft.x) * scale, bottomLeft.y + (center.y - bottomLeft.y) * scale);
    CGPoint innerCircleTouchPoint2 = CGPointMake(bottomRight.x + (center.x - bottomRight.x) * scale, bottomRight.y + (center.y - bottomRight.y) * scale);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, self.bottomColor.CGColor);
    
    CGContextMoveToPoint(context, 0, bottomLeft.y + 0);
    CGContextAddLineToPoint(context, 0, innerCircleTouchPoint.y-innerCircleTouchPoint.x);
    CGContextAddArcToPoint(context, innerCircleTouchPoint.x, innerCircleTouchPoint.y - innerCircleTouchPoint.x, innerCircleTouchPoint.x, innerCircleTouchPoint.y, innerCircleTouchPoint.x);
    CGContextAddLineToPoint(context, innerCircleTouchPoint.x, innerCircleTouchPoint.y);
    CGContextAddArcToPoint(context, a/2, (size.height-radius)*2, innerCircleTouchPoint2.x, innerCircleTouchPoint2.y, radius);
    CGContextAddArcToPoint(context, innerCircleTouchPoint2.x, innerCircleTouchPoint2.y - (a-innerCircleTouchPoint2.x), a, innerCircleTouchPoint2.y - (a-innerCircleTouchPoint2.x), (a-innerCircleTouchPoint2.x));
    CGContextAddLineToPoint(context, a, innerCircleTouchPoint2.y - (a-innerCircleTouchPoint2.x));
    CGContextAddLineToPoint(context, a, bottomRight.y + 0);
    CGContextFillPath(context);
    
    
    center = CGPointMake(size.width / 2, size.height);
    bottomLeft = CGPointMake(0, 0);
    bottomRight = CGPointMake(size.width - 0, 0);
    
    a = size.width;
    b = hypotf(center.x - bottomLeft.x, center.y - bottomLeft.y);
    s = (2*b+a)/2;
    radius = sqrt((s-a)*(s-b)*(s-b)/s);
    scale = radius / size.height;
    innerCircleTouchPoint = CGPointMake(bottomLeft.x + (center.x - bottomLeft.x) * scale, bottomLeft.y + (center.y - bottomLeft.y) * scale);
    innerCircleTouchPoint2 = CGPointMake(bottomRight.x + (center.x - bottomRight.x) * scale, bottomRight.y + (center.y - bottomRight.y) * scale);
    
    CGContextSetFillColorWithColor(context, self.bottomColor.CGColor);
    
    CGContextMoveToPoint(context, 0, bottomLeft.y + 0);
    CGContextAddLineToPoint(context, 0, innerCircleTouchPoint.y-innerCircleTouchPoint.x);
    CGContextAddArcToPoint(context, innerCircleTouchPoint.x, innerCircleTouchPoint.y - innerCircleTouchPoint.x, innerCircleTouchPoint.x, innerCircleTouchPoint.y, innerCircleTouchPoint.x);
    CGContextAddLineToPoint(context, innerCircleTouchPoint.x, innerCircleTouchPoint.y);
    CGContextAddArcToPoint(context, a/2, (size.height-radius)*2, innerCircleTouchPoint2.x, innerCircleTouchPoint2.y, radius);
    CGContextAddArcToPoint(context, innerCircleTouchPoint2.x, innerCircleTouchPoint2.y - (a-innerCircleTouchPoint2.x), a, innerCircleTouchPoint2.y - (a-innerCircleTouchPoint2.x), (a-innerCircleTouchPoint2.x));
    CGContextAddLineToPoint(context, a, innerCircleTouchPoint2.y - (a-innerCircleTouchPoint2.x));
    CGContextAddLineToPoint(context, a, bottomRight.y + 0);
    CGContextFillPath(context);*/
}

@end

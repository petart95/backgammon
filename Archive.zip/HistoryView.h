//
//  HistoryView.h
//  backgamon
//
//  Created by maxeler on 1/23/17.
//  Copyright © 2017 maxeler. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistoryView : UIView

@property NSDictionary *parents;

@end
